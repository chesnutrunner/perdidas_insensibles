package com.example.perdidas_insensibles_calculadora

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}